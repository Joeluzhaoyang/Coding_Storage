//
// Created by Yigit Sen on 27/10/2022.
//

#include "BST_PostOffice.h"

// TODO: Constructors and Destructors

//TIP: root will be nullptr at first, and we'll add a node once we try to add a mail object.
BST_PostOffice::BST_PostOffice()
{
    this->root = nullptr;
}

BST_PostOffice_Node::BST_PostOffice_Node(Mail *mail)
{
    this->left = nullptr;
    this->right = nullptr;
    this->district = mail->getDistrict();
    //this->mailman[mail->getAddressHash()].addMail(mail);
}

BST_PostOffice::~BST_PostOffice()
{
    if(root != nullptr){
        delete root;
    }
}

BST_PostOffice_Node::~BST_PostOffice_Node()
{
    if(this->getLeftBST() != nullptr){
        delete left;
    }
    if(this->getRightBST() != nullptr){
        delete right;
    }
}

// TODO: Accessor functions.
BST_PostOffice * BST_PostOffice_Node::getLeftBST() const
{
    return this->left;
}

BST_PostOffice * BST_PostOffice_Node::getRightBST() const
{
    return this->right;
}

District BST_PostOffice_Node::getDistrict() const
{
    return this->district;
}


//TODO: Given a district, id and street name, find the mail object.
Mail *BST_PostOffice::find(District dist, int id, std::string streetName)
{
}

Mail *BST_PostOffice_Node::find(int id, std::string streetName)
{
}


// TODO: Given a district, id and street name, remove the mail object from the
// system.
bool BST_PostOffice::remove(District dist, int id, std::string streetName)
{
}

bool BST_PostOffice_Node::remove(int id, std::string streetName)
{
}

// TODO: Add mail to the system
void BST_PostOffice::addMail(Mail *mail)
{
    if(root == nullptr){
        root = new BST_PostOffice_Node(mail);
    }
    if(mail->getDistrict() == this->root->getDistrict()){
        this->root->addMail(mail);
        //std::cout << root << std::endl;
    }
    else if (mail->getDistrict() < this->root->getDistrict()){
        if(root->getLeftBST() == nullptr){
            root->left = new BST_PostOffice();
        }
        this->root->left->addMail(mail);
    }
    else if(mail->getDistrict() > this->root->getDistrict()){
        if (root->getRightBST() == nullptr){
            root->right = new BST_PostOffice();
        }
        this->root->right->addMail(mail);
    }
}

void BST_PostOffice_Node::addMail(Mail *mail){
    // std::cout << mail->getAddressHash() << std::endl;
    mailman[mail->getAddressHash()].addMail(mail);
}

// TODO: Given a district, print all of the data in it.
// TIP: Print style depends on type.
void BST_PostOffice::printDistrict(District dist, printType type) const
{
    if(this->root->district == dist){
        std::cout<<"The District Mail Report for district "<<dist<<std::endl;
        this->root->print(type);
    }
    else if (dist < this->root->district && root->left != nullptr){
        this->root->left->printDistrict(dist,type);
    }
    else if (dist > this->root->district && root->right != nullptr){
        this->root->right->printDistrict(dist, type);
    }
    return;
    //     for (BST_PostOffice_Node *a = this->root; a != nullptr; a = a->getLeftBST()->root)
    //     {
    //         printDistrict(dist, type);
    //     }
    // for (BST_PostOffice_Node *a = this->root; a != nullptr; a = a->getRightBST()->root){
    //     printDistrict(dist, type);
    // }
}

void BST_PostOffice_Node::print(printType type) const
{
    for(int i = 0; i<HASH_MODULO;i++){
        std::cout <<"For Mailman "<<i<<std::endl;
        switch (type)
        {
        case printType::inorder:
            mailman[i].printInOrder();
            break;
        case printType::postorder:
            mailman[i].printPostOrder();
            break;
        case printType::preorder :
            mailman[i].printPreOrder();
            break;
        default:
            break;
        }
    }
}

// TODO: Given a district and ID of the mailman, print all mail in it
// TIP: Print style depends on type - see the header file
void BST_PostOffice::printMailman(District district, int i, printType type) const
{
}

void BST_PostOffice_Node::printMailman(int i, printType type) const
{
}

// TODO: Other print functions.
void BST_PostOffice::printInOrder() const
{
}

void BST_PostOffice::printPostOrder() const
{
}

void BST_PostOffice::printPreOrder() const
{
}